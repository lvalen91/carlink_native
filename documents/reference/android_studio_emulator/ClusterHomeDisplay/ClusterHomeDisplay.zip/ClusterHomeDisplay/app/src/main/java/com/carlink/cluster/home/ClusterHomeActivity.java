package com.carlink.cluster.home;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.MediaMetadata;
import android.media.session.MediaController;
import android.media.session.MediaSessionManager;
import android.media.session.PlaybackState;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.RemoteException;
import android.util.Log;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.carlink.ipc.INaviVideoSink;
import com.carlink.ipc.INaviVideoSource;

import java.io.InputStream;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

/**
 * Unified cluster home activity. Hosts navigation (left pane) + media (right pane)
 * simultaneously on the 1920x720 cluster canvas. Replaces the toggle-via-VHAL pattern
 * used by the sibling ClusterNavigationActivity and ClusterMediaActivity.
 *
 * Data sources:
 *   - Navigation: ClusterHomeManager.registerClusterNavigationStateListener
 *     (NavigationStateProto byte[] from Templates Host)
 *   - Media: MediaSessionManager.getActiveSessions + OnActiveSessionsChangedListener
 *     + MediaController.Callback (metadata, playback state, album art)
 *
 * RRO overrides BOTH config_clusterMapActivity AND config_clusterMusicActivity
 * (priority=100, above per-slot sibling overlays at priority=99) so VHAL values 1 and 2
 * both land here.
 */
public class ClusterHomeActivity extends Activity {

    private static final String TAG = "CarlinkHome";

    // Keep-alive: when Templates Host's ClusterTurnCardActivity preempts us on display 3,
    // re-launch ourselves. Capped to avoid infinite ping-pong if Templates Host re-takes.
    private static final long RELAUNCH_DELAY_MS = 1500L;
    private static final int RELAUNCH_MAX_BURST = 5;       // attempts within window
    private static final long RELAUNCH_WINDOW_MS = 30_000L;
    private static final int CLUSTER_DISPLAY_ID = 3;

    // If no NavigationState arrives within this window, treat as nav-ended and clear views.
    private static final long NAV_IDLE_TIMEOUT_MS = 5_000L;

    // Producer service (carlink_native). Bind to receive AltVideo (USB 0x2C) frames.
    private static final String NAVI_VIDEO_PKG = "zeno.carlink";
    private static final String NAVI_VIDEO_SERVICE =
            "zeno.carlink.ipc.NaviVideoSourceService";
    // Auto-rebind backoff (after producer reinstall / crash / disconnect).
    private static final long NAVI_REBIND_MIN_DELAY_MS = 1_000L;
    private static final long NAVI_REBIND_MAX_DELAY_MS = 30_000L;
    // If the producer goes quiet after onStreamConfigured but before first frame,
    // hide the overlay so we fall back to the cards. The producer SHOULD send
    // onStreamEnded, but this guards against a producer-side crash mid-session.
    private static final long VIDEO_FIRST_FRAME_TIMEOUT_MS = 3_000L;

    private long relaunchWindowStart = 0L;
    private int relaunchBurstCount = 0;
    private final Runnable relaunchSelf = this::relaunchOnCluster;
    private final Runnable navIdleClear = this::clearNavDisplay;
    private final Runnable videoFirstFrameTimeout = this::hideVideoOverlay;
    private final Runnable rebindNaviVideoSource = this::bindNaviVideoSource;
    private long naviRebindDelayMs = NAVI_REBIND_MIN_DELAY_MS;

    // ---- Nav reflection constants ----
    private static final String CAR_CLASS = "android.car.Car";
    private static final String NAV_LISTENER_IFACE =
            "android.car.cluster.ClusterHomeManager$ClusterNavigationStateListener";
    private static final String CLUSTER_HOME_SERVICE = "cluster_home_service";

    // ---- Nav views ----
    private ImageView maneuverIcon;
    private TextView distanceView;
    private TextView instructionView;
    private TextView etaView;

    // ---- Media views ----
    private ImageView albumArt;
    private TextView trackTitle;
    private TextView artistName;
    private TextView playbackStateView;

    // ---- Status footer ----
    private TextView statusView;

    // ---- AltVideo overlay (USB 0x2C) ----
    private SurfaceView naviVideoView;
    private NaviDecoder naviDecoder;
    private INaviVideoSource naviVideoSource;
    private boolean naviVideoBound = false;
    private boolean naviStreamActive = false;
    private int naviStreamW, naviStreamH, naviStreamFps;

    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private final ExecutorService iconExecutor = Executors.newSingleThreadExecutor();
    private final SimpleDateFormat clock = new SimpleDateFormat("HH:mm:ss", Locale.US);

    // ---- Nav state ----
    private Object car;
    private Object clusterHomeManager;
    private Object navListenerProxy;
    private String lastIconUri;
    private volatile int lastNavBytes = 0;
    private volatile long lastNavTs = 0;

    // ---- Media state ----
    private MediaSessionManager mediaSessionManager;
    private MediaController activeController;

    private final MediaSessionManager.OnActiveSessionsChangedListener sessionsListener =
            this::onActiveSessionsChanged;

    private final MediaController.Callback controllerCallback = new MediaController.Callback() {
        @Override
        public void onMetadataChanged(MediaMetadata metadata) {
            mainHandler.post(() -> updateMetadata(metadata));
        }

        @Override
        public void onPlaybackStateChanged(PlaybackState state) {
            mainHandler.post(() -> updatePlaybackState(state));
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cluster_home);

        maneuverIcon = findViewById(R.id.maneuver_icon);
        distanceView = findViewById(R.id.distance);
        instructionView = findViewById(R.id.instruction);
        etaView = findViewById(R.id.eta);

        albumArt = findViewById(R.id.album_art);
        trackTitle = findViewById(R.id.track_title);
        artistName = findViewById(R.id.artist_name);
        playbackStateView = findViewById(R.id.playback_state);

        statusView = findViewById(R.id.status);

        naviVideoView = findViewById(R.id.navi_video);
        naviVideoView.getHolder().addCallback(surfaceCallback);
        naviDecoder = new NaviDecoder(decoderCallback, mainHandler);

        bindClusterHomeManager();
        bindMediaSessions();
        bindNaviVideoSource();
    }

    @Override
    protected void onResume() {
        super.onResume();
        mainHandler.removeCallbacks(relaunchSelf);
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (isFinishing() || isChangingConfigurations()) return;
        long now = System.currentTimeMillis();
        if (now - relaunchWindowStart > RELAUNCH_WINDOW_MS) {
            relaunchWindowStart = now;
            relaunchBurstCount = 0;
        }
        if (relaunchBurstCount >= RELAUNCH_MAX_BURST) {
            Log.w(TAG, "Keep-alive burst cap hit (" + RELAUNCH_MAX_BURST
                    + "/" + RELAUNCH_WINDOW_MS + "ms); backing off until window resets");
            return;
        }
        relaunchBurstCount++;
        Log.i(TAG, "Preempted on cluster — scheduling re-foreground in "
                + RELAUNCH_DELAY_MS + "ms (attempt " + relaunchBurstCount + ")");
        mainHandler.postDelayed(relaunchSelf, RELAUNCH_DELAY_MS);
    }

    /**
     * Re-foreground via CarPropertyManager.setIntProperty(CLUSTER_SWITCH_UI=1).
     * That tells ClusterHomeService to launch config_clusterMapActivity = us (via RRO).
     * Avoids setLaunchDisplayId which needs platform signing.
     *
     * NOTE: This only wins until zeno.carlink's ClusterMainSession.navigationStarted()
     * fires again — at which point Templates Host preempts us. For permanent dominance,
     * gate navigationStarted() behind actual NavigationState arrival in
     * carlink_native/app/src/main/kotlin/com/carlink/cluster/ClusterMainSession.kt:137.
     */
    private void relaunchOnCluster() {
        try {
            if (clusterHomeManager == null) {
                Log.w(TAG, "Keep-alive: ClusterHomeManager not bound yet");
                return;
            }
            Object propMgr = car.getClass().getMethod("getCarManager", String.class)
                    .invoke(car, "property");
            if (propMgr == null) {
                Log.w(TAG, "Keep-alive: CarPropertyManager unavailable");
                return;
            }
            propMgr.getClass().getMethod("setIntProperty", int.class, int.class, int.class)
                    .invoke(propMgr, 0x11400F34, 0, 1);
            Log.i(TAG, "Keep-alive: requested CLUSTER_SWITCH_UI=MAPS");
        } catch (Throwable t) {
            Log.w(TAG, "Keep-alive failed: " + t.getMessage());
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        mainHandler.removeCallbacks(relaunchSelf);
        mainHandler.removeCallbacks(navIdleClear);
        mainHandler.removeCallbacks(videoFirstFrameTimeout);
        mainHandler.removeCallbacks(rebindNaviVideoSource);
        unbindClusterHomeManager();
        unbindMediaSessions();
        unbindNaviVideoSource();
        if (naviDecoder != null) {
            naviDecoder.release();
            naviDecoder = null;
        }
        iconExecutor.shutdownNow();
    }

    // ====================== NAV ======================

    private void bindClusterHomeManager() {
        try {
            Class<?> carClass = Class.forName(CAR_CLASS);
            Method createCar = carClass.getMethod("createCar", Context.class);
            car = createCar.invoke(null, this);
            if (car == null) {
                setStatus("Car service unavailable");
                return;
            }

            Method getCarManager = carClass.getMethod("getCarManager", String.class);
            clusterHomeManager = getCarManager.invoke(car, CLUSTER_HOME_SERVICE);
            if (clusterHomeManager == null) {
                setStatus("ClusterHomeManager not available");
                return;
            }

            Class<?> listenerIface = Class.forName(NAV_LISTENER_IFACE);
            navListenerProxy = Proxy.newProxyInstance(
                    listenerIface.getClassLoader(),
                    new Class<?>[]{listenerIface},
                    new NavListenerHandler());

            Method register = clusterHomeManager.getClass().getMethod(
                    "registerClusterNavigationStateListener", Executor.class, listenerIface);
            register.invoke(clusterHomeManager, (Executor) mainHandler::post, navListenerProxy);

            Log.i(TAG, "Registered ClusterNavigationStateListener");
        } catch (Throwable t) {
            Log.e(TAG, "Failed to bind ClusterHomeManager", t);
            setStatus("Nav bind error: " + t.getClass().getSimpleName());
        }
    }

    private void unbindClusterHomeManager() {
        try {
            if (clusterHomeManager != null && navListenerProxy != null) {
                Class<?> listenerIface = Class.forName(NAV_LISTENER_IFACE);
                Method unregister = clusterHomeManager.getClass().getMethod(
                        "unregisterClusterNavigationStateListener", listenerIface);
                unregister.invoke(clusterHomeManager, navListenerProxy);
            }
            if (car != null) {
                Method disconnect = car.getClass().getMethod("disconnect");
                disconnect.invoke(car);
            }
        } catch (Throwable t) {
            Log.w(TAG, "Nav unbind error: " + t.getMessage());
        }
    }

    private final class NavListenerHandler implements InvocationHandler {
        @Override
        public Object invoke(Object proxy, Method method, Object[] args) {
            if ("onNavigationStateChanged".equals(method.getName())
                    && args != null && args.length == 1 && args[0] instanceof byte[]) {
                byte[] proto = (byte[]) args[0];
                lastNavBytes = proto.length;
                lastNavTs = System.currentTimeMillis();
                NavState s = ProtoSniffer.parse(proto);
                mainHandler.post(() -> renderNav(s));
            }
            return null;
        }
    }

    private void renderNav(NavState s) {
        if (isEmptyNav(s)) {
            Log.i(TAG, "Nav end: empty NavigationState — clearing views");
            mainHandler.removeCallbacks(navIdleClear);
            clearNavDisplay();
            return;
        }

        mainHandler.removeCallbacks(navIdleClear);
        mainHandler.postDelayed(navIdleClear, NAV_IDLE_TIMEOUT_MS);

        if (s.cue != null && !s.cue.isEmpty()) {
            instructionView.setText(s.cue);
        }
        String distText = formatDistance(s);
        if (distText != null) {
            distanceView.setText(distText);
        }
        StringBuilder eta = new StringBuilder();
        if (s.destinationName != null) eta.append(s.destinationName);
        if (s.destDisplayDistance != null) {
            if (eta.length() > 0) eta.append("  ·  ");
            eta.append(s.destDisplayDistance).append(unitSuffix(s.destDistanceUnit));
        }
        etaView.setText(eta.toString());

        if (s.iconUri != null && !s.iconUri.equals(lastIconUri)) {
            lastIconUri = s.iconUri;
            fetchIcon(s.iconUri);
        }
        updateStatus();
    }

    private static boolean isEmptyNav(NavState s) {
        return (s.cue == null || s.cue.isEmpty())
                && s.displayDistance == null
                && s.distanceMeters == 0
                && s.iconUri == null
                && s.destinationName == null
                && s.destDisplayDistance == null;
    }

    private void clearNavDisplay() {
        long sinceLast = lastNavTs > 0 ? (System.currentTimeMillis() - lastNavTs) : -1;
        Log.i(TAG, "clearNavDisplay (last nav " + sinceLast + "ms ago, "
                + lastNavBytes + " B)");
        instructionView.setText("");
        distanceView.setText("");
        etaView.setText("");
        maneuverIcon.setImageDrawable(null);
        lastIconUri = null;
        updateStatus();
    }

    private void fetchIcon(String uriStr) {
        iconExecutor.submit(() -> {
            try (InputStream in = getContentResolver().openInputStream(Uri.parse(uriStr))) {
                if (in == null) {
                    Log.w(TAG, "icon stream null: " + uriStr);
                    return;
                }
                Bitmap bmp = BitmapFactory.decodeStream(in);
                if (bmp != null) {
                    mainHandler.post(() -> maneuverIcon.setImageBitmap(bmp));
                }
            } catch (SecurityException e) {
                Log.w(TAG, "no permission for " + uriStr + ": " + e.getMessage());
            } catch (Exception e) {
                Log.w(TAG, "icon fetch: " + e.getMessage());
            }
        });
    }

    private static String formatDistance(NavState s) {
        if (s.displayDistance != null) {
            return s.displayDistance + unitSuffix(s.distanceUnit);
        }
        if (s.distanceMeters > 0) {
            return s.distanceMeters >= 1000
                    ? String.format(Locale.US, "%.1f km", s.distanceMeters / 1000.0)
                    : s.distanceMeters + " m";
        }
        return null;
    }

    private static String unitSuffix(int unit) {
        switch (unit) {
            case 1: return " m";
            case 2: return " km";
            case 3: return " mi";
            case 4: return " ft";
            case 5: return " yd";
            default: return "";
        }
    }

    // ====================== MEDIA ======================

    private void bindMediaSessions() {
        mediaSessionManager = getSystemService(MediaSessionManager.class);
        if (mediaSessionManager == null) {
            Log.e(TAG, "MediaSessionManager unavailable");
            trackTitle.setText("Media service unavailable");
            return;
        }
        try {
            List<MediaController> controllers = mediaSessionManager.getActiveSessions(null);
            onActiveSessionsChanged(controllers);
            mediaSessionManager.addOnActiveSessionsChangedListener(sessionsListener, null);
            Log.i(TAG, "Registered media session listener, " + controllers.size() + " active");
        } catch (SecurityException e) {
            Log.e(TAG, "No permission for getActiveSessions: " + e.getMessage());
            trackTitle.setText("No Permission");
            artistName.setText("Grant MEDIA_CONTENT_CONTROL");
        }
    }

    private void unbindMediaSessions() {
        if (activeController != null) {
            try { activeController.unregisterCallback(controllerCallback); } catch (Exception ignored) {}
            activeController = null;
        }
        if (mediaSessionManager != null) {
            try { mediaSessionManager.removeOnActiveSessionsChangedListener(sessionsListener); }
            catch (Exception e) { Log.w(TAG, "removeOnActiveSessionsChangedListener: " + e.getMessage()); }
        }
    }

    private void onActiveSessionsChanged(List<MediaController> controllers) {
        if (controllers == null || controllers.isEmpty()) {
            clearMediaDisplay();
            return;
        }
        MediaController controller = controllers.get(0);
        if (activeController != null
                && activeController.getSessionToken().equals(controller.getSessionToken())) {
            return;
        }
        if (activeController != null) {
            activeController.unregisterCallback(controllerCallback);
        }
        activeController = controller;
        activeController.registerCallback(controllerCallback, mainHandler);
        Log.i(TAG, "Tracking media session: " + controller.getPackageName());
        updateMetadata(controller.getMetadata());
        updatePlaybackState(controller.getPlaybackState());
    }

    private void updateMetadata(MediaMetadata metadata) {
        if (metadata == null) {
            trackTitle.setText("No Media Playing");
            artistName.setText("");
            albumArt.setImageResource(R.drawable.ic_music_note);
            return;
        }
        String title = metadata.getString(MediaMetadata.METADATA_KEY_TITLE);
        String artist = metadata.getString(MediaMetadata.METADATA_KEY_ARTIST);
        Bitmap art = metadata.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART);
        if (art == null) art = metadata.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON);

        trackTitle.setText(title != null ? title : "Unknown");
        artistName.setText(artist != null ? artist : "");
        if (art != null) albumArt.setImageBitmap(art);
        else albumArt.setImageResource(R.drawable.ic_music_note);
    }

    private void updatePlaybackState(PlaybackState state) {
        if (state == null) { playbackStateView.setText(""); return; }
        switch (state.getState()) {
            case PlaybackState.STATE_PLAYING:
                playbackStateView.setText("Now Playing");
                playbackStateView.setTextColor(0xFF4CAF50);
                break;
            case PlaybackState.STATE_PAUSED:
                playbackStateView.setText("Paused");
                playbackStateView.setTextColor(0xFFFF9800);
                break;
            case PlaybackState.STATE_STOPPED:
                playbackStateView.setText("Stopped");
                playbackStateView.setTextColor(0xFF666666);
                break;
            case PlaybackState.STATE_BUFFERING:
                playbackStateView.setText("Buffering...");
                playbackStateView.setTextColor(0xFF666666);
                break;
            default:
                playbackStateView.setText("");
                break;
        }
    }

    private void clearMediaDisplay() {
        trackTitle.setText("No Media Playing");
        artistName.setText("");
        playbackStateView.setText("");
        albumArt.setImageResource(R.drawable.ic_music_note);
        if (activeController != null) {
            activeController.unregisterCallback(controllerCallback);
            activeController = null;
        }
    }

    // ====================== ALT VIDEO (USB 0x2C) ======================

    /**
     * Bind to carlink_native's NaviVideoSourceService. Graceful no-op if the
     * package isn't installed or the service is missing — the cards UI still
     * works without the overlay.
     */
    private void bindNaviVideoSource() {
        mainHandler.removeCallbacks(rebindNaviVideoSource);
        // If a prior bind is still registered (e.g. retry after onServiceDisconnected),
        // unbind it first; bindService() with the same ServiceConnection twice silently
        // no-ops and never delivers a fresh onServiceConnected.
        if (naviVideoBound) {
            try { unbindService(naviVideoConn); } catch (Throwable ignored) {}
            naviVideoBound = false;
        }
        try {
            Intent intent = new Intent();
            intent.setComponent(new ComponentName(NAVI_VIDEO_PKG, NAVI_VIDEO_SERVICE));
            boolean ok = bindService(intent, naviVideoConn, Context.BIND_AUTO_CREATE);
            if (!ok) {
                Log.i(TAG, "NaviVideoSource not available (degraded mode) — retrying in "
                        + naviRebindDelayMs + "ms");
                try { unbindService(naviVideoConn); } catch (Exception ignored) {}
                scheduleRebindLocked();
            } else {
                naviVideoBound = true;
                Log.i(TAG, "Bound NaviVideoSourceService");
            }
        } catch (Throwable t) {
            Log.w(TAG, "bindNaviVideoSource: " + t.getMessage());
            scheduleRebindLocked();
        }
    }

    /** Schedule the next bind attempt with exponential backoff (1s → 30s, capped). */
    private void scheduleRebindLocked() {
        mainHandler.removeCallbacks(rebindNaviVideoSource);
        mainHandler.postDelayed(rebindNaviVideoSource, naviRebindDelayMs);
        naviRebindDelayMs = Math.min(naviRebindDelayMs * 2, NAVI_REBIND_MAX_DELAY_MS);
    }

    private void unbindNaviVideoSource() {
        mainHandler.removeCallbacks(rebindNaviVideoSource);
        if (!naviVideoBound) return;
        try {
            if (naviVideoSource != null) {
                try { naviVideoSource.unregisterSink(naviSink); } catch (RemoteException ignored) {}
            }
            unbindService(naviVideoConn);
        } catch (Throwable t) {
            Log.w(TAG, "unbindNaviVideoSource: " + t.getMessage());
        }
        naviVideoBound = false;
        naviVideoSource = null;
    }

    private final ServiceConnection naviVideoConn = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            naviVideoSource = INaviVideoSource.Stub.asInterface(service);
            naviRebindDelayMs = NAVI_REBIND_MIN_DELAY_MS; // reset backoff on success
            try {
                service.linkToDeath(() -> mainHandler.post(() -> {
                    Log.w(TAG, "NaviVideoSource died — scheduling rebind in "
                            + naviRebindDelayMs + "ms");
                    naviVideoSource = null;
                    hideVideoOverlay();
                    scheduleRebindLocked();
                }), 0);
                naviVideoSource.registerSink(naviSink);
                if (naviVideoSource.isStreamActive()) {
                    Log.i(TAG, "Stream already active on bind — awaiting onStreamConfigured");
                }
            } catch (RemoteException e) {
                Log.w(TAG, "registerSink: " + e.getMessage());
            }
        }
        @Override
        public void onServiceDisconnected(ComponentName name) {
            Log.w(TAG, "NaviVideoSource disconnected — scheduling rebind in "
                    + naviRebindDelayMs + "ms");
            naviVideoSource = null;
            mainHandler.post(() -> {
                hideVideoOverlay();
                scheduleRebindLocked();
            });
        }
    };

    /**
     * The sink implementation. All callbacks land on a binder thread; we marshal
     * to the main handler for view changes and into the decoder for frames.
     */
    private final INaviVideoSink.Stub naviSink = new INaviVideoSink.Stub() {
        @Override
        public void onStreamConfigured(int width, int height, int fps) {
            Log.i(TAG, "AltVideo stream configured: " + width + "x" + height + "@" + fps);
            naviStreamActive = true;
            naviStreamW = width;
            naviStreamH = height;
            naviStreamFps = fps;
            if (naviDecoder != null) naviDecoder.setStreamInfo(width, height, fps);
            mainHandler.post(ClusterHomeActivity.this::showVideoOverlay);
        }

        @Override
        public void onFrame(byte[] h264AnnexB, long ptsUs, boolean isKeyFrame) {
            if (naviDecoder != null) {
                naviDecoder.queueFrame(h264AnnexB, ptsUs, isKeyFrame);
            }
        }

        @Override
        public void onStreamEnded() {
            Log.i(TAG, "AltVideo stream ended");
            naviStreamActive = false;
            mainHandler.post(ClusterHomeActivity.this::hideVideoOverlay);
        }
    };

    private void showVideoOverlay() {
        if (naviVideoView == null) return;
        // Lock the SurfaceView's buffer to the announced stream geometry. The View
        // bounds are 1920x620 (root FrameLayout, no padding), so when streamW/H also
        // = 1920/620 the mapping is 1:1 with no scaling. If a future session
        // negotiates a different size, the buffer follows and SurfaceFlinger does
        // a single aspect-preserving rescale.
        if (naviStreamW > 0 && naviStreamH > 0) {
            naviVideoView.getHolder().setFixedSize(naviStreamW, naviStreamH);
        }
        naviVideoView.setVisibility(View.VISIBLE);
        mainHandler.removeCallbacks(videoFirstFrameTimeout);
        mainHandler.postDelayed(videoFirstFrameTimeout, VIDEO_FIRST_FRAME_TIMEOUT_MS);
        updateStatus();
    }

    private void hideVideoOverlay() {
        if (naviVideoView == null) return;
        mainHandler.removeCallbacks(videoFirstFrameTimeout);
        naviVideoView.setVisibility(View.GONE);
        // surfaceDestroyed will fire from the View hierarchy and detach the decoder.
        naviStreamW = naviStreamH = naviStreamFps = 0;
        updateStatus();
    }

    private final SurfaceHolder.Callback surfaceCallback = new SurfaceHolder.Callback() {
        @Override
        public void surfaceCreated(SurfaceHolder holder) {
            Log.i(TAG, "navi_video surfaceCreated");
            if (naviDecoder != null) naviDecoder.setSurface(holder.getSurface());
        }
        @Override
        public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {
            // Width/height are the SurfaceView's pixel size on display 3 (1920x620 area
            // minus margins). The decoder reuses the same Surface; SurfaceFlinger scales
            // from streamWidth×streamHeight as needed.
        }
        @Override
        public void surfaceDestroyed(SurfaceHolder holder) {
            Log.i(TAG, "navi_video surfaceDestroyed");
            if (naviDecoder != null) naviDecoder.setSurface(null);
        }
    };

    private final NaviDecoder.Callback decoderCallback = new NaviDecoder.Callback() {
        @Override
        public void onFirstFrameDecoded() {
            Log.i(TAG, "AltVideo first frame on Surface");
            mainHandler.removeCallbacks(videoFirstFrameTimeout);
            updateStatus();
        }
        @Override
        public void onDecoderError(Throwable t) {
            Log.e(TAG, "AltVideo decoder error", t);
            hideVideoOverlay();
        }
    };

    // ====================== STATUS ======================

    private void setStatus(String msg) {
        if (statusView != null) {
            mainHandler.post(() -> statusView.setText(msg));
        }
    }

    private void updateStatus() {
        String navInfo = lastNavBytes > 0
                ? lastNavBytes + " B nav @ " + clock.format(new Date(lastNavTs))
                : "no nav";
        String mediaInfo = activeController != null
                ? "media: " + activeController.getPackageName()
                : "no media";
        String videoInfo = naviStreamActive
                ? "  ·  alt-video: " + naviStreamW + "x" + naviStreamH + "@" + naviStreamFps
                : "";
        statusView.setText(navInfo + "  ·  " + mediaInfo + videoInfo);
    }

    // ====================== PROTO SNIFFER ======================

    static final class NavState {
        int distanceMeters;
        String displayDistance;
        int distanceUnit;
        int maneuverType;
        int roundaboutExit;
        String iconUri;
        String cue;
        String destinationName;
        String destDisplayDistance;
        int destDistanceUnit;
    }

    /** Hand-rolled NavigationStateProto wire-format reader. See sibling ClusterNavigationActivity. */
    static final class ProtoSniffer {
        static NavState parse(byte[] data) {
            NavState out = new NavState();
            try { walkNavigationState(data, 0, data.length, out); }
            catch (Throwable t) { Log.w(TAG, "proto parse: " + t.getMessage()); }
            return out;
        }

        private static void walkNavigationState(byte[] b, int off, int end, NavState out) {
            int p = off; boolean firstStep = true;
            while (p < end) {
                long tag = readVarint(b, p);
                p += varintSize(tag);
                int fieldNum = (int) (tag >>> 3);
                int wire = (int) (tag & 0x7);
                if (wire == 2) {
                    long len = readVarint(b, p);
                    p += varintSize(len);
                    int start = p; int stop = (int) (p + len);
                    if (fieldNum == 1 && firstStep) { walkStep(b, start, stop, out); firstStep = false; }
                    else if (fieldNum == 2) { walkDestination(b, start, stop, out); }
                    p = stop;
                } else { p = skipField(b, p, wire); }
            }
        }

        private static void walkStep(byte[] b, int off, int end, NavState out) {
            int p = off;
            while (p < end) {
                long tag = readVarint(b, p);
                p += varintSize(tag);
                int fieldNum = (int) (tag >>> 3);
                int wire = (int) (tag & 0x7);
                if (wire == 2) {
                    long len = readVarint(b, p);
                    p += varintSize(len);
                    int start = p; int stop = (int) (p + len);
                    switch (fieldNum) {
                        case 1: walkDistance(b, start, stop, out, true); break;
                        case 2: walkManeuver(b, start, stop, out); break;
                        case 5: out.cue = readRichText(b, start, stop); break;
                        default: break;
                    }
                    p = stop;
                } else { p = skipField(b, p, wire); }
            }
        }

        private static void walkDistance(byte[] b, int off, int end, NavState out, boolean stepDistance) {
            int p = off;
            while (p < end) {
                long tag = readVarint(b, p);
                p += varintSize(tag);
                int fieldNum = (int) (tag >>> 3);
                int wire = (int) (tag & 0x7);
                if (fieldNum == 1 && wire == 0) {
                    long meters = readVarint(b, p); p += varintSize(meters);
                    if (stepDistance) out.distanceMeters = (int) meters;
                } else if (fieldNum == 2 && wire == 2) {
                    long len = readVarint(b, p); p += varintSize(len);
                    String s = new String(b, p, (int) len);
                    if (stepDistance) out.displayDistance = s; else out.destDisplayDistance = s;
                    p += len;
                } else if (fieldNum == 3 && wire == 0) {
                    long unit = readVarint(b, p); p += varintSize(unit);
                    if (stepDistance) out.distanceUnit = (int) unit; else out.destDistanceUnit = (int) unit;
                } else { p = skipField(b, p, wire); }
            }
        }

        private static void walkManeuver(byte[] b, int off, int end, NavState out) {
            int p = off;
            while (p < end) {
                long tag = readVarint(b, p);
                p += varintSize(tag);
                int fieldNum = (int) (tag >>> 3);
                int wire = (int) (tag & 0x7);
                if (fieldNum == 1 && wire == 0) {
                    long type = readVarint(b, p); p += varintSize(type); out.maneuverType = (int) type;
                } else if (fieldNum == 2 && wire == 0) {
                    long exit = readVarint(b, p); p += varintSize(exit); out.roundaboutExit = (int) exit;
                } else if (fieldNum == 3 && wire == 2) {
                    long len = readVarint(b, p); p += varintSize(len);
                    out.iconUri = readImageReferenceUri(b, p, (int) (p + len)); p += len;
                } else { p = skipField(b, p, wire); }
            }
        }

        private static String readImageReferenceUri(byte[] b, int off, int end) {
            int p = off;
            while (p < end) {
                long tag = readVarint(b, p);
                p += varintSize(tag);
                int fieldNum = (int) (tag >>> 3);
                int wire = (int) (tag & 0x7);
                if (fieldNum == 1 && wire == 2) {
                    long len = readVarint(b, p); p += varintSize(len);
                    return new String(b, p, (int) len);
                }
                p = skipField(b, p, wire);
            }
            return null;
        }

        private static String readRichText(byte[] b, int off, int end) {
            int p = off; String fallback = null; String firstElement = null;
            while (p < end) {
                long tag = readVarint(b, p);
                p += varintSize(tag);
                int fieldNum = (int) (tag >>> 3);
                int wire = (int) (tag & 0x7);
                if (wire == 2) {
                    long len = readVarint(b, p); p += varintSize(len);
                    if (fieldNum == 2 && fallback == null) fallback = new String(b, p, (int) len);
                    else if (fieldNum == 1 && firstElement == null) firstElement = readElementText(b, p, (int) (p + len));
                    p += len;
                } else { p = skipField(b, p, wire); }
            }
            return fallback != null ? fallback : firstElement;
        }

        private static String readElementText(byte[] b, int off, int end) {
            int p = off;
            while (p < end) {
                long tag = readVarint(b, p);
                p += varintSize(tag);
                int fieldNum = (int) (tag >>> 3);
                int wire = (int) (tag & 0x7);
                if (fieldNum == 1 && wire == 2) {
                    long len = readVarint(b, p); p += varintSize(len);
                    return new String(b, p, (int) len);
                }
                p = skipField(b, p, wire);
            }
            return null;
        }

        private static void walkDestination(byte[] b, int off, int end, NavState out) {
            int p = off;
            while (p < end) {
                long tag = readVarint(b, p);
                p += varintSize(tag);
                int fieldNum = (int) (tag >>> 3);
                int wire = (int) (tag & 0x7);
                if (wire == 2) {
                    long len = readVarint(b, p); p += varintSize(len);
                    if (fieldNum == 1 && out.destinationName == null) out.destinationName = new String(b, p, (int) len);
                    else if (fieldNum == 3) walkDistance(b, p, (int) (p + len), out, false);
                    p += len;
                } else { p = skipField(b, p, wire); }
            }
        }

        private static int skipField(byte[] b, int off, int wire) {
            switch (wire) {
                case 0: return off + varintSize(readVarint(b, off));
                case 1: return off + 8;
                case 5: return off + 4;
                case 2: { long len = readVarint(b, off); return off + varintSize(len) + (int) len; }
                default: throw new IllegalStateException("unknown wire " + wire);
            }
        }

        private static long readVarint(byte[] b, int off) {
            long v = 0; int shift = 0;
            while (true) {
                byte x = b[off++];
                v |= ((long) (x & 0x7F)) << shift;
                if ((x & 0x80) == 0) return v;
                shift += 7;
                if (shift > 63) throw new IllegalStateException("varint too long");
            }
        }

        private static int varintSize(long v) {
            int n = 1;
            while ((v & ~0x7FL) != 0) { v >>>= 7; n++; }
            return n;
        }
    }
}
