package com.carlink.cluster.home;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

import java.lang.reflect.Method;

/**
 * Replaces the manual `adb shell cmd car_service inject-vhal-event 0x11400F34 1` step that
 * both sibling stubs' READMEs document as required after every boot.
 *
 * Flips CLUSTER_SWITCH_UI (VENDOR_INT32_GLOBAL 0x11400F34) to 1 (MAPS) via CarPropertyManager.
 * That triggers AOSP ClusterHomeSample to launch config_clusterMapActivity, which our RRO
 * has redirected to com.carlink.cluster.home/.ClusterHomeActivity at priority=100.
 *
 * Auth: requires CAR_INSTRUMENT_CLUSTER_CONTROL (signature|privileged, granted via
 * privapp-permissions-clusterhome.xml). Does NOT need INTERNAL_SYSTEM_WINDOW —
 * the routing to display 3 is handled by ClusterHomeService, not by us.
 */
public class BootCompletedReceiver extends BroadcastReceiver {
    private static final String TAG = "CarlinkHome";
    private static final int CLUSTER_SWITCH_UI = 0x11400F34;
    private static final int UI_TYPE_MAPS = 1;

    @Override
    public void onReceive(Context context, Intent intent) {
        String action = intent != null ? intent.getAction() : null;
        if (!Intent.ACTION_BOOT_COMPLETED.equals(action)
                && !Intent.ACTION_LOCKED_BOOT_COMPLETED.equals(action)) {
            return;
        }
        try {
            Class<?> carClass = Class.forName("android.car.Car");
            Method createCar = carClass.getMethod("createCar", Context.class);
            Object car = createCar.invoke(null, context);
            if (car == null) {
                Log.w(TAG, "BootCompletedReceiver: Car service unavailable");
                return;
            }
            Method getCarManager = carClass.getMethod("getCarManager", String.class);
            Object propMgr = getCarManager.invoke(car, "property");
            if (propMgr == null) {
                Log.w(TAG, "BootCompletedReceiver: CarPropertyManager unavailable");
                return;
            }
            Method setIntProperty = propMgr.getClass().getMethod(
                    "setIntProperty", int.class, int.class, int.class);
            setIntProperty.invoke(propMgr, CLUSTER_SWITCH_UI, 0, UI_TYPE_MAPS);
            Log.i(TAG, "BootCompletedReceiver: set CLUSTER_SWITCH_UI=MAPS, ClusterHomeActivity should launch");
            try { carClass.getMethod("disconnect").invoke(car); } catch (Throwable ignored) {}
        } catch (Throwable t) {
            Log.w(TAG, "BootCompletedReceiver failed: " + t.getMessage());
        }
    }
}
