// SPDX-License-Identifier: Apache-2.0
package com.carlink.cluster.home;

import android.media.MediaCodec;
import android.media.MediaFormat;
import android.os.Handler;
import android.os.HandlerThread;
import android.util.Log;
import android.view.Surface;

import java.nio.ByteBuffer;
import java.util.ArrayDeque;

/**
 * H.264 (Annex-B) decoder for the CPC200 AltVideo (USB 0x2C) stream.
 *
 * Drives a single MediaCodec instance on its own HandlerThread. Frames pushed
 * via {@link #queueFrame} are buffered and drained on the codec thread; output
 * is rendered straight to the Surface provided by {@link #setSurface}.
 *
 * Until {@link #setSurface} receives a non-null Surface, frames are buffered
 * up to MAX_PENDING and then dropped (oldest first). After surface attach,
 * the decoder waits for the first IDR/keyframe before configuring — SPS/PPS
 * are inband and MediaCodec extracts them from the first access unit.
 *
 * Lifecycle: ClusterHomeActivity creates one instance, calls setSurface on
 * SurfaceHolder.surfaceCreated/Destroyed, calls release() in onDestroy.
 */
public final class NaviDecoder {

    private static final String TAG = "CarlinkHome.NaviDec";
    private static final String MIME = "video/avc";
    private static final int MAX_PENDING = 16;

    public interface Callback {
        /** Called on the main handler once per session, after the first decoded frame is released to the Surface. */
        void onFirstFrameDecoded();
        /** Called on the main handler when the codec hits an unrecoverable error. */
        void onDecoderError(Throwable t);
    }

    private static final class Frame {
        final byte[] nal;
        final long ptsUs;
        final boolean keyFrame;
        Frame(byte[] n, long p, boolean k) { nal = n; ptsUs = p; keyFrame = k; }
    }

    private final Callback callback;
    private final Handler mainHandler;
    private final ArrayDeque<Frame> pending = new ArrayDeque<>();

    private HandlerThread codecThread;
    private Handler codecHandler;
    private MediaCodec codec;
    private Surface surface;

    private int streamWidth = 1920;
    private int streamHeight = 620;
    private int streamFps = 30;

    private boolean configured = false;
    private boolean firstOutputDelivered = false;
    private boolean released = false;
    private int framesSeen = 0;
    private int framesDropped = 0;

    public NaviDecoder(Callback cb, Handler mainHandler) {
        this.callback = cb;
        this.mainHandler = mainHandler;
    }

    /** Update geometry from {@code onStreamConfigured}. Takes effect at next configure. */
    public synchronized void setStreamInfo(int w, int h, int fps) {
        if (w > 0) streamWidth = w;
        if (h > 0) streamHeight = h;
        if (fps > 0) streamFps = fps;
    }

    /**
     * Attach (non-null) or detach (null) the output Surface.
     * Detach stops the codec and clears pending frames.
     */
    public synchronized void setSurface(Surface s) {
        if (released) return;
        if (s == null) {
            stopCodecLocked();
            surface = null;
            return;
        }
        surface = s;
        if (codecThread == null) {
            codecThread = new HandlerThread("NaviCodec");
            codecThread.start();
            codecHandler = new Handler(codecThread.getLooper());
        }
        codecHandler.post(this::pumpLocked);
    }

    /** Push one access unit. Safe to call from any thread, including the AIDL binder thread. */
    public synchronized void queueFrame(byte[] nal, long ptsUs, boolean keyFrame) {
        if (released) return;
        framesSeen++;
        if (framesSeen <= 3 || (framesSeen % 30 == 0)) {
            Log.i(TAG, "queueFrame #" + framesSeen + " len=" + (nal == null ? -1 : nal.length)
                    + " pts=" + ptsUs + " key=" + keyFrame
                    + " head=" + nalHeadHex(nal)
                    + " surface=" + (surface != null ? "yes" : "no")
                    + " configured=" + configured);
        }
        if (surface == null) return;
        if (pending.size() >= MAX_PENDING) {
            pending.pollFirst();
            framesDropped++;
            Log.w(TAG, "queue full, dropped oldest frame (total dropped=" + framesDropped + ")");
        }
        pending.addLast(new Frame(nal, ptsUs, keyFrame));
        if (codecHandler != null) codecHandler.post(this::pumpLocked);
    }

    /** Hex of the first 8 bytes, for diagnosing the wire format we're being handed. */
    private static String nalHeadHex(byte[] nal) {
        if (nal == null || nal.length == 0) return "<empty>";
        StringBuilder sb = new StringBuilder();
        int n = Math.min(nal.length, 8);
        for (int i = 0; i < n; i++) sb.append(String.format("%02X ", nal[i]));
        return sb.toString().trim();
    }

    /** Tear down. Safe to call multiple times. */
    public synchronized void release() {
        if (released) return;
        released = true;
        stopCodecLocked();
        if (codecThread != null) {
            codecThread.quitSafely();
            codecThread = null;
            codecHandler = null;
        }
        pending.clear();
        surface = null;
    }

    // ===== Codec-thread body =====

    private void pumpLocked() {
        synchronized (this) {
            if (released || surface == null) return;
            drainInputLocked();
            if (configured && codec != null) drainOutputLocked();
        }
    }

    private void drainInputLocked() {
        while (!pending.isEmpty()) {
            Frame f = pending.peekFirst();
            if (!configured) {
                if (!f.keyFrame) {
                    if ((framesDropped & 0x3F) == 0) {
                        Log.w(TAG, "waiting for keyframe, dropping non-key frame "
                                + "(len=" + f.nal.length + ", head=" + nalHeadHex(f.nal) + ")");
                    }
                    pending.pollFirst();
                    framesDropped++;
                    continue;
                }
                Log.i(TAG, "keyframe arrived (len=" + f.nal.length + ", head="
                        + nalHeadHex(f.nal) + "); configuring codec");
                try {
                    configureAndStartLocked(f.nal);
                } catch (Throwable t) {
                    Log.e(TAG, "configure failed", t);
                    pending.clear();
                    notifyError(t);
                    return;
                }
            }
            int idx;
            try {
                idx = codec.dequeueInputBuffer(0);
            } catch (Throwable t) {
                Log.w(TAG, "dequeueInputBuffer: " + t.getMessage());
                return;
            }
            if (idx < 0) return;
            pending.pollFirst();
            try {
                ByteBuffer in = codec.getInputBuffer(idx);
                if (in == null) return;
                in.clear();
                in.put(f.nal);
                int flag = f.keyFrame ? MediaCodec.BUFFER_FLAG_KEY_FRAME : 0;
                codec.queueInputBuffer(idx, 0, f.nal.length, f.ptsUs, flag);
            } catch (Throwable t) {
                Log.w(TAG, "queueInputBuffer: " + t.getMessage());
                return;
            }
        }
    }

    private void drainOutputLocked() {
        MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
        while (true) {
            int idx;
            try {
                idx = codec.dequeueOutputBuffer(info, 0);
            } catch (Throwable t) {
                Log.w(TAG, "dequeueOutputBuffer: " + t.getMessage());
                return;
            }
            if (idx == MediaCodec.INFO_TRY_AGAIN_LATER) return;
            if (idx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                Log.i(TAG, "output format: " + codec.getOutputFormat());
                continue;
            }
            if (idx < 0) continue;
            try {
                codec.releaseOutputBuffer(idx, true);
            } catch (Throwable t) {
                Log.w(TAG, "releaseOutputBuffer: " + t.getMessage());
                return;
            }
            if (!firstOutputDelivered) {
                firstOutputDelivered = true;
                Log.i(TAG, "first decoded frame released to Surface");
                if (callback != null) mainHandler.post(callback::onFirstFrameDecoded);
            }
        }
    }

    private void configureAndStartLocked(byte[] csdSeed) throws Exception {
        Log.i(TAG, "configuring decoder " + streamWidth + "x" + streamHeight + "@" + streamFps);
        codec = MediaCodec.createDecoderByType(MIME);
        MediaFormat fmt = MediaFormat.createVideoFormat(MIME, streamWidth, streamHeight);
        fmt.setInteger(MediaFormat.KEY_FRAME_RATE, streamFps);

        // Lift SPS (NAL type 7) and PPS (NAL type 8) out of the keyframe access unit
        // and supply them as csd-0 / csd-1. The emulator's software AVC decoder is
        // strict about CSD; relying on inband SPS/PPS at the head of the first input
        // buffer works on some HW decoders but fails on the emulator.
        byte[] sps = findNalUnit(csdSeed, 7);
        byte[] pps = findNalUnit(csdSeed, 8);
        if (sps != null && pps != null) {
            Log.i(TAG, "extracted SPS (" + sps.length + " B) + PPS (" + pps.length + " B) as CSD");
            fmt.setByteBuffer("csd-0", ByteBuffer.wrap(sps));
            fmt.setByteBuffer("csd-1", ByteBuffer.wrap(pps));
        } else {
            Log.w(TAG, "keyframe missing SPS/PPS in same access unit (sps=" + (sps != null)
                    + " pps=" + (pps != null) + "); configuring without explicit CSD — "
                    + "decoder may fail to lock if it's strict");
        }

        codec.configure(fmt, surface, null, 0);
        codec.start();
        configured = true;
        firstOutputDelivered = false;
    }

    /**
     * Find the first NAL unit of the given type in an Annex-B byte stream and return it
     * with its start-code prefix, ready to feed back to MediaCodec verbatim. Returns null
     * if not found.
     */
    private static byte[] findNalUnit(byte[] buf, int nalType) {
        int p = 0;
        while (p < buf.length) {
            int sc = findStartCode(buf, p);
            if (sc < 0) return null;
            // sc points at the index AFTER the start code (where the NAL header byte sits).
            if (sc >= buf.length) return null;
            int type = buf[sc] & 0x1F;
            int nextSc = findStartCode(buf, sc + 1);
            // Walk the start-code prefix back to its leading zero(s).
            int prefixStart = sc - 1;
            while (prefixStart > 0 && buf[prefixStart - 1] == 0) prefixStart--;
            // Include the byte AT prefixStart, which is the first 0x00.
            int end = (nextSc < 0) ? buf.length : findStartCodePrefixStart(buf, nextSc);
            if (type == nalType) {
                byte[] out = new byte[end - prefixStart];
                System.arraycopy(buf, prefixStart, out, 0, out.length);
                return out;
            }
            p = (nextSc < 0) ? buf.length : nextSc;
        }
        return null;
    }

    /** Returns the index immediately AFTER the start code (i.e. of the NAL header byte). */
    private static int findStartCode(byte[] buf, int from) {
        for (int i = from; i < buf.length - 2; i++) {
            if (buf[i] == 0 && buf[i + 1] == 0 && buf[i + 2] == 1) return i + 3;
            if (i < buf.length - 3 && buf[i] == 0 && buf[i + 1] == 0
                    && buf[i + 2] == 0 && buf[i + 3] == 1) return i + 4;
        }
        return -1;
    }

    /** Given the index of a NAL header byte (i.e. after a start code), find where the */
    /** preceding start code's leading 0x00 begins. */
    private static int findStartCodePrefixStart(byte[] buf, int headerIdx) {
        int p = headerIdx - 1; // 0x01 byte
        // 00 00 01 → step back 2; 00 00 00 01 → step back 3.
        int back = p - 2;
        if (back >= 0 && buf[back] == 0 && back > 0 && buf[back - 1] == 0) back--;
        return Math.max(back, 0);
    }

    private void stopCodecLocked() {
        configured = false;
        firstOutputDelivered = false;
        if (codec != null) {
            try { codec.stop(); } catch (Throwable ignored) {}
            try { codec.release(); } catch (Throwable ignored) {}
            codec = null;
        }
        pending.clear();
    }

    private void notifyError(Throwable t) {
        if (callback != null) mainHandler.post(() -> callback.onDecoderError(t));
    }
}
