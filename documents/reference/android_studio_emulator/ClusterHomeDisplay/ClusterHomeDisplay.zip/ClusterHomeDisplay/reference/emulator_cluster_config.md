# Emulator Cluster Display Config (verified 2026-05-27/28)

Snapshot of the **actual** local AVD + on-device cluster configuration used to
develop and verify the ClusterHomeDisplay + AltVideo (0x2C) integration. Pulled
from a running `wideAAOS` AVD on `emulator-5554`.

Anyone implementing the producer side should treat `1920×620` as the authoritative
sandbox size for `naviScreenInfo`. The numbers below show *why*.

---

## 1. AVD: `~/.android/avd/wideAAOS.avd/config.ini`

Driver-facing IHU display is defined explicitly; **cluster display is NOT defined here**
(it's created at runtime by `ClusterOsDouble`).

```ini
# IHU (driver) display — the main 2400×960 panel
hw.lcd.width=2400
hw.lcd.height=960
hw.lcd.density=160

# Extra display slot, unused for cluster (small dev/preview panel)
hw.display6.density=120
hw.display6.flag=0
hw.display6.height=600
hw.display6.width=400

# Automotive build flag
tag.display=Automotive
tag.displaynames=Automotive,Google APIs
hw.initialOrientation=landscape
hw.device.name=ultrawideAAOS 1
```

There is a `config.ini.bak-pre1920cluster` backup that pre-dates the current setup;
the diff vs. the live `config.ini` shows no display-related changes (only ramSize,
cpu cores, gpu mode), confirming the cluster panel size is **not** controlled here.

## 2. AVD: `~/.android/avd/wideAAOS.avd/hardware-qemu.ini`

QEMU emulator hardware. Slots `hw.display1..3` are present but all zeroed —
multi-display is wired up via the Automotive tag + ClusterOsDouble, not direct QEMU
displays.

```ini
hw.lcd.width = 2400
hw.lcd.height = 960
hw.lcd.density = 160

hw.display1.width = 0
hw.display1.height = 0
hw.display1.density = 0
hw.display1.flag = 0
hw.display2.width = 0
hw.display2.height = 0
hw.display3.width = 0
hw.display3.height = 0
```

## 3. AVD: `~/.android/avd/wideAAOS.avd/emu-launch-params.txt`

Note the USB passthrough — when this matters for AltVideo (CPC200-CCPA VID/PID),
the adapter is reachable inside the emulator without an extra adb-usb shim.

```
emulator -avd wideaaos
  -usb-passthrough vendorid=0x1314,productid=0x1520
  -usb-passthrough vendorid=0x1314,productid=0x1521
  -selinux permissive
  -writable-system
  -no-snapshot
```

## 4. On-device: `ClusterOsDouble.apk` dimens (decoded)

Resource encoding: `data = (mantissa << 8) | (radix << 4) | unit`,
where `unit == 1` ⇒ dp.

| Resource | Hex `data` | Decoded |
|---|---|---|
| `dimen/info_height` | `0x00006401` | **100 dp** — the bottom strip (PRND, Fuel/Range, native nav widget) |
| `dimen/speedometer_width` | `0x00025801` | 600 dp — gauge cluster width |
| `dimen/speedometer_overlap_width` | `0x00005a01` | 90 dp |
| `dimen/speedometer_top` | `0x00001401` | 20 dp |
| `dimen/navigation_gradient_height` | `0x00000f01` | 15 dp |

Pulled with:
```
adb pull /system/app/ClusterOsDouble/ClusterOsDouble.apk
"$ANDROID_HOME/build-tools/<ver>/aapt" dump --values resources ClusterOsDouble.apk \
  | grep -E "0x7f0600(76|86|a[6789])"
```

Layout: `res/layout/cluster_os_double_activity.xml` (binary AXML in the APK)
contains a `SurfaceView @id/cluster_display` whose height is `match_constraint`
between the top of the activity and a `LinearLayout` of height `info_height`
anchored to the bottom. **That SurfaceView is what backs the cluster VirtualDisplay.**

So: VD height = physical 720 − `info_height` 100 = **620**. Width is the full 1920.

## 5. Live: `adb shell dumpsys display`

Authoritative runtime values. Treat these as ground truth.

```
DisplayDeviceInfo{"ClusterOsDouble-VD":
  uniqueId  = "virtual:com.android.car.cluster.osdouble:ClusterDisplay"
  real      = 1920 x 620
  modeId    = 3, supportedModes [{width=1920, height=620, fps=60.0}]
  density   = 160 (160.0 x 160.0 dpi)
  type      = VIRTUAL
  owner     = com.android.car.cluster.osdouble (uid 1000)
  flags     = FLAG_PRIVATE | FLAG_NEVER_BLANK | FLAG_OWN_CONTENT_ONLY
  state     = ON
  mDisplayId = 3
}

DisplayDeviceInfo{"Built-in Screen" (EMU_display_1, HWC port 1):
  real      = 1920 x 720
  modeId    = 2, fps = 160 Hz
  type      = INTERNAL
  density   = 160
  state     = ON
  ...HWC display token id 4619827551948147201
}
```

## 6. Live: `adb shell dumpsys window displays`

Activity-facing geometry on display 3 (what `ClusterHomeActivity` sees):

```
displayId=3, mLogicalSize=1920x620
DisplayFrames w=1920 h=620 r=0
nonDecorInsets=[0,0][0,0]   ← no insets
configFrame=[0,0][1920,620]

Window{... com.carlink.cluster.home/.ClusterHomeActivity}:
  frame=[Rect(0, 0 - 1920, 620)]
  touchableRegion=SkRegion((0,0,1920,620))
  scaleFactor=1.0
  contentSize=1920x620
```

## 7. Display topology summary

```
EMU_display_1 (HWC port 1) — 1920×720, INTERNAL                ← physical cluster screen
└── com.android.car.cluster.osdouble/.ClusterOsDoubleActivity
    │  draws gauge cluster (speedo arcs + PRND)
    │  draws bottom strip via dimen/info_height = 100 dp
    │
    └── SurfaceView @id/cluster_display
        └── VirtualDisplay "ClusterOsDouble-VD" (displayId=3) — 1920×620
            └── com.carlink.cluster.home/.ClusterHomeActivity ← we live here
```

The reachable canvas for any guest cluster activity (us, Templates Host
ClusterActivity, default ClusterHomeActivity) is exactly **1920×620**, with
no insets. The 100 px below us is owned by ClusterOsDouble and unreachable.

## 8. Useful one-liners

```bash
# Confirm VD size on a fresh emulator
adb shell dumpsys display | grep -A1 'ClusterOsDouble-VD'

# Confirm guest activity bounds on display 3
adb shell dumpsys window displays | sed -n '/displayId=3/,/displayId=/p' | head -25

# Find current HWC token for screencap (changes per emulator instance)
adb shell dumpsys SurfaceFlinger --display-id | grep EMU_display_1

# Screencap the full 1920×720 physical cluster panel
adb exec-out screencap -p -d 4619827551948147201 > /tmp/cluster.png
```
